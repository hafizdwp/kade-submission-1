package me.hafizdwp.kade_submission_1

/**
 * @author hafizdwp
 * 29/10/2019
 **/
interface MainActionListener {
    fun onClick(data: LeagueData)
}